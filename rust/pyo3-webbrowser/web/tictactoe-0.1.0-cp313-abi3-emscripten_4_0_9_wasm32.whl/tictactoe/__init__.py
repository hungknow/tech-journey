from .tictactoe import *

__doc__ = tictactoe.__doc__
if hasattr(tictactoe, "__all__"):
    __all__ = tictactoe.__all__